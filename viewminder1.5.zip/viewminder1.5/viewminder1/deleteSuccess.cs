﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viewminder1
{
    public partial class deleteSuccess : Form
    {
        public deleteSuccess()
        {
            InitializeComponent();
        }

        private void Guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }
    }
}
